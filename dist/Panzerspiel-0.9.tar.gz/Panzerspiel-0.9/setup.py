from distutils.core import setup

setup(
    name='Panzerspiel',
    version='0.9',
    packages=['panzerspiel', ],
    license='GNU General Public License v3.0',
    long_description=open('README.md').read(),
    include_package_data=True,
    package_data={'panzerspiel': ['res2/*.*', 'res2/music/*.mp3']}
)
